import { motion } from "framer-motion";
import { Award, User } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src={`${import.meta.env.BASE_URL}images/about-img.png`} 
                alt="Printed Circuit Board" 
                className="w-full h-auto object-cover aspect-[4/3] hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
            </div>
            
            {/* Floating Badge */}
            <div className="absolute -bottom-8 -right-8 bg-white p-6 rounded-2xl shadow-xl shadow-black/10 border border-gray-100 hidden md:block animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-300">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-secondary/10 text-secondary rounded-full flex items-center justify-center">
                  <Award size={24} />
                </div>
                <div>
                  <p className="font-bold text-primary text-xl">100+</p>
                  <p className="text-sm text-muted-foreground">Projects Delivered</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-secondary font-bold tracking-wider uppercase text-sm mb-3">About Us</h2>
            <h3 className="text-3xl md:text-4xl font-bold text-primary mb-6 font-display leading-tight">
              Pioneering End-to-End Embedded Product Solutions
            </h3>
            
            <div className="space-y-6 text-lg text-muted-foreground mb-8 leading-relaxed">
              <p>
                S A Innovix Solutions is a premier professional embedded systems company. We specialize in transforming complex technical requirements into robust, production-ready hardware and software solutions.
              </p>
              <p>
                Our comprehensive approach ensures that every phase of product development—from initial schematic design to final firmware deployment and PCB assembly—is executed with uncompromising precision and quality.
              </p>
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 flex items-start gap-4">
              <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center shrink-0">
                <User size={24} />
              </div>
              <div>
                <h4 className="text-lg font-bold text-primary font-display">Abhijeet Narayan Singh</h4>
                <p className="text-secondary font-medium text-sm mb-2">CEO & Lead Engineer</p>
                <p className="text-sm text-muted-foreground">
                  Driving innovation with years of specialized experience in embedded systems architecture and project delivery.
                </p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
