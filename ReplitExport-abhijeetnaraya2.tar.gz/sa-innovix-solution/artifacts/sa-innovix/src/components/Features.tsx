import { motion } from "framer-motion";
import { CheckCircle2, Clock, HeadphonesIcon, ShieldCheck } from "lucide-react";

const features = [
  {
    icon: ShieldCheck,
    title: "Expert Team",
    description: "Industry veterans with deep knowledge of embedded architectures."
  },
  {
    icon: CheckCircle2,
    title: "Quality Guaranteed",
    description: "Rigorous testing protocols ensuring flawless deployment."
  },
  {
    icon: Clock,
    title: "On-Time Delivery",
    description: "Strict adherence to project timelines and milestones."
  },
  {
    icon: HeadphonesIcon,
    title: "Customer Support",
    description: "Dedicated technical assistance throughout the product lifecycle."
  }
];

export function Features() {
  return (
    <section className="py-20 bg-primary relative overflow-hidden">
      {/* Decorative abstract elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-secondary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col items-center text-center group"
            >
              <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-secondary mb-6 group-hover:bg-secondary group-hover:text-white transition-all duration-300 group-hover:scale-110 shadow-lg">
                <feature.icon size={28} />
              </div>
              <h4 className="text-xl font-bold text-white mb-3 font-display">{feature.title}</h4>
              <p className="text-white/70 text-sm leading-relaxed max-w-[250px]">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
