export function Footer() {
  return (
    <footer className="bg-primary pt-16 pb-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-center md:text-left mb-12">
          
          <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center overflow-hidden relative shadow-lg">
                <img 
                  src={`${import.meta.env.BASE_URL}images/logo-icon.png`} 
                  alt="Logo" 
                  className="w-full h-full object-cover scale-125"
                />
              </div>
            <span className="font-display font-bold text-xl tracking-tight text-white">
              S A Innovix Solutions
            </span>
          </div>
          
          <p className="text-white/60 font-medium">
            Engineering Excellence in Embedded Systems & Hardware.
          </p>
          
        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/40">
          <p>&copy; {new Date().getFullYear()} S A Innovix Solutions. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
