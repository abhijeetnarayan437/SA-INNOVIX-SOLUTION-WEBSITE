import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { MapPin, Mail, Phone, FileText, Send, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type FormValues = z.infer<typeof formSchema>;

export function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    
    toast({
      title: "Message Sent Successfully!",
      description: "We'll get back to you as soon as possible.",
      duration: 5000,
    });
    
    reset();
  };

  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-secondary font-bold tracking-wider uppercase text-sm mb-3">Get in Touch</h2>
          <h3 className="text-3xl md:text-5xl font-bold text-primary mb-6 font-display">Ready to Start Your Project?</h3>
          <p className="text-muted-foreground text-lg">
            Contact us today for a technical consultation or to request a detailed quote for your embedded systems requirements.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
          
          {/* Contact Information (Left Side - spans 2 cols) */}
          <div className="lg:col-span-2 bg-primary p-10 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            
            <h4 className="text-2xl font-bold mb-8 font-display relative z-10">Contact Information</h4>
            
            <div className="space-y-8 relative z-10">
              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg text-secondary">
                  <User size={20} />
                </div>
                <div>
                  <p className="text-sm text-white/60 mb-1">CEO & Contact Person</p>
                  <p className="font-semibold text-lg">Abhijeet Narayan Singh</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg text-secondary">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-sm text-white/60 mb-1">Phone / WhatsApp</p>
                  <a href="#" className="font-medium hover:text-secondary transition-colors">+91 (Replace with actual)</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg text-secondary">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-sm text-white/60 mb-1">Email Address</p>
                  <a href="#" className="font-medium hover:text-secondary transition-colors">contact@sainnovix.com</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg text-secondary">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="text-sm text-white/60 mb-1">Location</p>
                  <p className="font-medium">India</p>
                </div>
              </div>

              <div className="pt-8 mt-8 border-t border-white/10 flex items-start gap-4">
                <div className="mt-1 bg-white/10 p-2 rounded-lg text-secondary">
                  <FileText size={20} />
                </div>
                <div>
                  <p className="text-sm text-white/60 mb-1">Business Registration</p>
                  <p className="font-medium font-mono">PAN: JPKPS2617H</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form (Right Side - spans 3 cols) */}
          <div className="lg:col-span-3 p-10 lg:p-12">
            <h4 className="text-2xl font-bold text-primary mb-8 font-display">Send us a Message</h4>
            
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-semibold text-primary">Full Name</label>
                  <input
                    id="name"
                    {...register("name")}
                    className={`w-full px-4 py-3 rounded-xl bg-gray-50 border ${errors.name ? 'border-destructive focus:ring-destructive/20' : 'border-gray-200 focus:border-secondary focus:ring-secondary/20'} text-primary placeholder:text-gray-400 focus:outline-none focus:ring-4 transition-all`}
                    placeholder="John Doe"
                  />
                  {errors.name && <p className="text-destructive text-xs mt-1">{errors.name.message}</p>}
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-semibold text-primary">Email Address</label>
                  <input
                    id="email"
                    type="email"
                    {...register("email")}
                    className={`w-full px-4 py-3 rounded-xl bg-gray-50 border ${errors.email ? 'border-destructive focus:ring-destructive/20' : 'border-gray-200 focus:border-secondary focus:ring-secondary/20'} text-primary placeholder:text-gray-400 focus:outline-none focus:ring-4 transition-all`}
                    placeholder="john@example.com"
                  />
                  {errors.email && <p className="text-destructive text-xs mt-1">{errors.email.message}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-semibold text-primary">Project Details</label>
                <textarea
                  id="message"
                  rows={5}
                  {...register("message")}
                  className={`w-full px-4 py-3 rounded-xl bg-gray-50 border ${errors.message ? 'border-destructive focus:ring-destructive/20' : 'border-gray-200 focus:border-secondary focus:ring-secondary/20'} text-primary placeholder:text-gray-400 focus:outline-none focus:ring-4 transition-all resize-none`}
                  placeholder="Tell us about your embedded software or hardware needs..."
                />
                {errors.message && <p className="text-destructive text-xs mt-1">{errors.message.message}</p>}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-8 py-4 rounded-xl font-semibold bg-secondary text-white hover:bg-secondary/90 shadow-lg shadow-secondary/25 hover:shadow-xl hover:shadow-secondary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </span>
                ) : (
                  <>
                    Send Message <Send size={18} />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

// Temporary User Icon component since it wasn't imported from lucide-react above
function User(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}
