import { motion } from "framer-motion";
import { Code2, Cpu, Microchip } from "lucide-react";

const services = [
  {
    icon: Code2,
    title: "Embedded Software",
    description: "Custom firmware development, RTOS implementation, device drivers, and microcontroller programming optimized for performance and reliability.",
    price: "₹20,000 / Project",
    delay: 0.1,
  },
  {
    icon: Cpu,
    title: "Hardware Design",
    description: "Comprehensive custom PCB schematics, precise component selection, and rigorous signal integrity analysis for robust hardware architecture.",
    price: "Custom Quote",
    delay: 0.2,
  },
  {
    icon: Microchip,
    title: "PCB Assembly",
    description: "Professional SMT and through-hole assembly services, strict quality inspection, scaling seamlessly from rapid prototypes to full production.",
    price: "Custom Quote",
    delay: 0.3,
  }
];

export function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-secondary font-bold tracking-wider uppercase text-sm mb-3">Our Expertise</h2>
          <h3 className="text-3xl md:text-5xl font-bold text-primary mb-6 font-display">Specialized Engineering Services</h3>
          <p className="text-muted-foreground text-lg">
            Delivering robust hardware and software solutions tailored to your exact technical specifications.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: service.delay }}
              className="bg-white rounded-3xl p-8 shadow-lg shadow-black/5 border border-gray-100 hover:border-secondary/30 hover:shadow-2xl hover:shadow-secondary/10 hover:-translate-y-2 transition-all duration-300 group flex flex-col h-full"
            >
              <div className="w-16 h-16 rounded-2xl bg-blue-50 text-secondary flex items-center justify-center mb-6 group-hover:bg-secondary group-hover:text-white transition-colors duration-300">
                <service.icon size={32} strokeWidth={1.5} />
              </div>
              
              <h4 className="text-2xl font-bold text-primary mb-4 font-display">{service.title}</h4>
              <p className="text-muted-foreground flex-grow mb-8 leading-relaxed">
                {service.description}
              </p>
              
              <div className="mt-auto pt-6 border-t border-gray-100 flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500 uppercase tracking-wider">Starting at</span>
                <span className="text-lg font-bold text-primary">{service.price}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
